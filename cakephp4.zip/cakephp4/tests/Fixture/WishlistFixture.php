<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * WishlistFixture
 */
class WishlistFixture extends TestFixture
{
    /**
     * Table name
     *
     * @var string
     */
    public $table = 'wishlist';
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'Id' => 1,
                'users_id' => 1,
                'products_id' => 1,
            ],
        ];
        parent::init();
    }
}
