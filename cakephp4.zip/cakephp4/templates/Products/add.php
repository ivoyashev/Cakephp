<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Product $product
 */
?>
<div class="row">
    <div class="column-responsive column-80">
        <div class="products form content">
            <?= $this->Form->create($product, ['type'=>'file']) ?>
            <fieldset>
                <legend class="legendUser"><?= __('Add Product') ?></legend>
                <?= $this->Html->css('style.css') ?>
                <?= $this->Html->link(__('List Products'), ['action' => 'index'], ['class' => 'submitNewUser1']) ?>
                <?php
                    echo $this->Form->control('name');
                    echo $this->Form->control('price');
                    echo $this->Form->control('size');
                    echo $this->Form->control('description');
                    echo $this->Form->control('image_file', ['type'=>'file']);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Add'), ['class' => 'submit']) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>