<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Product $product
 */
?>
<div class="row">
    <div class="column-responsive column-80">
        <div class="products form content">
            <?= $this->Form->create($product, ['type'=> 'file']) ?>
            <fieldset>
                <legend class="legendUser"><?= __('Edit Product') ?></legend>
                <?= $this->Html->css('style.css')?>
                <?= $this->Html->link(__('List Products'), ['action' => 'index'], ['class' => 'submitNewUser1']) ?>
                <?php
                    echo $this->Form->control('name');
                    echo $this->Form->control('price');
                    echo $this->Form->control('size');
                    echo $this->Form->control('description');
                    echo $this->Form->control('change_image',['type'=> 'file']);
                ?>
            </fieldset>
             <?= $this->Form->button(__('Edit'), ['class' => 'submit']) ?>
                 <?= $this->Html->link(__('Cancel'), $this->request->referer(), ['class' => ' btn_cancel']) ?><br>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
<style type="text/css">
    .btn_cancel{
    background-color: red;
    color: white;
    display: block;
    height: 40px;
    line-height: 40px;
    text-decoration: none;
    width: 100px;
    text-align: center;
        width: 50%;
    
    border: 1px solid;
 
    border-radius: 25px;
    font-size: 18px;

    font-weight: 700;
    cursor: pointer;
    outline: none;
    margin-left: 25%;

}
.btn_cancel:hover {
  color: white;
  background-color: #606c76;
}
</style>