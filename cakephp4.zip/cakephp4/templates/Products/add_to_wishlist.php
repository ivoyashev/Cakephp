<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Product $product
 */
?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<?= $this->Html->css('style.css') ?>
<?= $this->Html->css('bootstrap.min.css') ?>

<div class="row">
    <aside class="column">
        <div class="side-nav">

            <link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet" id="bootstrap-css">
        <script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
        <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

            <div class="btn btn-primary" >
                    <i class="icon-pencil icon-white"></i>
                    <?= $this->Html->link(__('New Product'), ['action' => 'add'], ['id' => 'txt_new_user']) ?>
            </div>
            <div class="btn btn-primary">
                    <i class="icon-eye-open icon-white"></i>
                    <?= $this->Html->link(__('List Products'), ['action' => 'index'], ['id' => 'txt_new_user']) ?>          
            </div> 
            <div class="btn btn-primary">
                <i class="icon-edit icon-white"></i>
                <?= $this->Html->link(__('Edit Product'), ['action' => 'edit', $product->id], ['id' => 'txt_new_user']) ?>
            </div>
            <div class="btn btn-primary">
                <i class="icon-trash icon-white"></i>
                <?= $this->Form->postLink(__('Delete Product'), ['action' => 'delete', $product->id],['id' => 'txt_delete_user'], ['confirm' => __('Are you sure you want to delete # {0}?', $product->id)]) ?>
            </div>  
        </div>
    </aside>
    <div class="container" style="width: 84%;">    
                <div class="jumbotron">

                  <div class="row">
                      <div class="col-md-4 col-xs-12 col-sm-6 col-lg-4">
                          <?= @$this->Html->image($product->image, ['style' => 'width:256px; height:256px ']) ?>
                      </div>
                      <div class="col-md-8 col-xs-12 col-sm-6 col-lg-8">
                          <div class="container" style="border-bottom:1px solid black;" >
                            <h2>Product ID: <?= h($product->id) ?></h2>
                          </div>
                            <br>
                          <ul class="container details">
                            <li><p><span class="  glyphicon glyphicon-font" style="width:50px;"></span> <?= h($product->name) ?></p></li>
                            <li><p><span class="glyphicon glyphicon-usd" style="width:50px;"></span> <?= h($product->price) ?></p></li>
                            <li><p><span class="glyphicon glyphicon-resize-small" style="width:50px;"></span> <?= h($product->size) ?></p></li>
                            <li><p><span class="glyphicon glyphicon-pencil" style="width:50px;"></span> <?= h($product->description) ?></p>
                          </ul>

                      </div>
                  </div>
                </div>
<style type="text/css">
body {
    background: #e3edfd;
}
.details li {
    list-style: none;
}
li {
    margin-bottom:10px;
}
.span1 a{
    margin-bottom: 5%;
    margin-left: -50%;
    }
#txt_new_user{
      color: white;
    }
#txt_list_user{
      color: white;
    }
#txt_edit_user{
      color: white;
    }
#txt_delete_user{
      color: white;
    }
.btn-primary {
margin-top: 3%;
background-color: #2691d9;
display: flex;
justify-content: space-around;
}       
 .jumbotron{
  background-color: white;
 } 
 a {
    color: #000000;
    text-decoration: none;
}     
</style>