<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\Product> $products
 */
?>
           
<style type="text/css">
    
    img {
    max-width: 100%;
    width: 100px;
    height: 100px;
    border-radius: 50%;
}
.btn_details{

    color: white;
    text-decoration: none;
    background-color: transparent;

}#users_link{
        
    color: black;
    text-decoration: none;
    background-color: transparent;

    }

@media (max-width: 767.98px) { .border-sm-start-none { border-left: none !important; } }
</style>
<?= $this->Html->css('style.css') ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">           

<body style="background-color: #e3edfd;">
  <div class="container py-5">
    <?php foreach ($products as $product): ?>
      <div class="row justify-content-center mb-3">
        <div class="col-md-12 col-xl-10">
          <div class="card shadow-0 border rounded-3">
            <div class="card-body">
              <div class="row">
                <div class="col-md-12 col-lg-3 col-xl-3 mb-4 mb-lg-0">
                  <div class="bg-image hover-zoom ripple rounded ripple-surface">
                    <?= @$this->Html->image($product->image) ?>
                    <a href="#!">
                      <div class="hover-overlay">
                        <div class="mask" style="background-color: rgba(253, 253, 253, 0.15);"></div>
                      </div>
                    </a>
                  </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-6">
                  <b><h5><?= h($product->name) ?></h5></b>
                  <div class="d-flex flex-row">
                    <div class="text-danger mb-1 me-2">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                    </div>
                    <span><?= $this->Number->format($product->size) ?></span>
                  </div>
                  <p class="text-truncate mb-4 mb-md-0">
                    There are many variations of passages of Lorem Ipsum available, but the
                    majority have suffered alteration in some form, by injected humour, or
                    randomised words which don't look even slightly believable.
                    <?= h($product->description) ?>
                  </p>
                </div>
                <div class="col-md-6 col-lg-3 col-xl-3 border-sm-start-none border-start">
                  <div class="d-flex flex-row align-items-center mb-1">
                    <h4 class="mb-1 me-1">$<?= $this->Number->format($product->price) ?></h4>
                  </div>
                  <h6 class="text-success">Free shipping</h6>
                  <div class="d-flex flex-column mt-4">
                    <button class="btn btn-primary btn-sm" type="button"><?= $this->Html->link(__('Details'), ['action' => 'view', $product->id], ['class' => 'btn_details']) ?></button>
                    <button class="btn btn-outline-primary btn-sm mt-2" type="button">
                      <?= $this->Html->link(__('Add to Wishlist'), ['controller' => 'Products', 'action' => 'addToWishlist', $product->id], ['class' => 'btn btn-primary']) ?>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</body>