<?php
/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link          https://cakephp.org CakePHP(tm) Project
 * @since         0.10.0
 * @license       https://opensource.org/licenses/mit-license.php MIT License
 * @var \App\View\AppView $this
 */

$cakeDescription = 'CakePHP: the rapid development php framework';
?>
<!DOCTYPE html>
<html>
<head>
    <?= $this->Html->charset() ?>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>
        <?= $cakeDescription ?>:
        <?= $this->fetch('title') ?>
    </title>
    <?= $this->Html->meta('icon') ?>
    <?= $this->Html->css('milligram.min.css') ?>
    <?= $this->Html->css('cake.css') ?>
    <?= $this->fetch('meta') ?>
    <?= $this->fetch('css') ?>
    <?= $this->fetch('script') ?>
</head>
<body>
    <nav class="top-nav">
        <div class="top-nav-title">
            <a href="https://cakephp.org/" target="_blank"><span>Cake</span>PHP</a>
        </div>
        <div class="top-nav-links" style="
    font-size: 15px">
            <?php if($this->request->getSession()->read('Auth.User.id')) { ?>

             <a><?php echo $this->request->getSession()->read('Auth.User.email'); ?></a>
                  <?php 
                   if( $this->request->getParam('controller') == "Users") { ?>
                        <a><?php echo $this->Html->link('Products', ['controller'=>'products', 'action'=>'index'],['id' => 'users_link']); ?></a>
                  <?php }else { ?>
                        <a><?php echo $this->Html->link('Users', ['controller'=>'users', 'action'=>'index'], ['id' => 'users_link']); ?></a>
                        <a><?php echo $this->Html->link('Preview', ['controller'=>'products', 'action'=>'preview'], ['id' => 'users_link']); ?></a>
                 <?php } ?>

            <a id="logout_link"><?php echo $this->Html->link('Logout', ['controller'=>'users', 'action'=>'logout'],['id' => 'users_link']); ?></a>
        <?php }else { ?>
            <a><?php echo $this->Html->link('Signup', ['controller'=>'users', 'action'=>'signup'],['id' => 'users_link']); ?> </a>
            <a><?php echo $this->Html->link('Login', ['controller'=>'users', 'action'=>'login'],['id' => 'users_link']); ?> </a>
            
        <?php } ?>
        </div>
    </nav>
    <main class="main">
        <div class="container">
            <?= $this->Flash->render() ?>
            <?= $this->fetch('content') ?>
        </div>
    </main>
    <footer>
    </footer>
</body>
</html>
