<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\User $user
 */
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <?= $this->Html->css('style.css') ?>
  </head>
  <body>
        <div class="center">
           <?= $this->Form->create(null,['class' => 'form']) ?> 
            <fieldset>
               <h1><?= __('Login') ?></h1>
               <div class="txt_field">
                    <?php echo $this->Form->input('email', ['id' => 'txt_field1']); ?>   
                    <span></span>
                    <label>Email</label>
                </div>
                <div class="txt_field">
                    <?php echo $this->Form->password('password', ['id' => 'txt_field1']); ?>   
                    <span></span>
                    <label>Password</label>
                </div>
            </fieldset>
            <?= $this->Form->button(__('Login'), ['class' => 'submit']) ?>
            <?= $this->Form->end() ?>
        </div>
  </body>
</html>