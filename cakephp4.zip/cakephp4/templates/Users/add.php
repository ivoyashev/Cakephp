<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\User $user
 */
?>
<div class="row">
    <div class="column-responsive column-80">
        <div class="users form content">
            <?= $this->Form->create($user) ?>
            <fieldset>
                <legend class="legendUser"><?= __('Add User') ?></legend>
                <?= $this->Html->css('style.css') ?>
                <?= $this->Html->link(__('List Users'), ['action' => 'index'], ['class' => 'submitNewUser1']) ?>
                <?php
                    echo $this->Form->control('email');
                    echo $this->Form->control('password');
                    echo $this->Form->control('phone');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Add'), ['class' => 'submit']) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>