<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\Wishlist> $wishlist
 */
?>
<div class="wishlist index content">
    <?= $this->Html->link(__('New Wishlist'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Wishlist') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('Id') ?></th>
                    <th><?= $this->Paginator->sort('users_id') ?></th>
                    <th><?= $this->Paginator->sort('products_id') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($wishlist as $wishlist): ?>
                <tr>
                    <td><?= $this->Number->format($wishlist->Id) ?></td>
                    <td><?= $wishlist->has('user') ? $this->Html->link($wishlist->user->id, ['controller' => 'Users', 'action' => 'view', $wishlist->user->id]) : '' ?></td>
                    <td><?= $wishlist->has('product') ? $this->Html->link($wishlist->product->name, ['controller' => 'Products', 'action' => 'view', $wishlist->product->id]) : '' ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $wishlist->Id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $wishlist->Id]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $wishlist->Id], ['confirm' => __('Are you sure you want to delete # {0}?', $wishlist->Id)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
