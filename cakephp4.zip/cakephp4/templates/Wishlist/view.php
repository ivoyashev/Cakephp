<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Wishlist $wishlist
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Wishlist'), ['action' => 'edit', $wishlist->Id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Wishlist'), ['action' => 'delete', $wishlist->Id], ['confirm' => __('Are you sure you want to delete # {0}?', $wishlist->Id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Wishlist'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Wishlist'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="wishlist view content">
            <h3><?= h($wishlist->Id) ?></h3>
            <table>
                <tr>
                    <th><?= __('User') ?></th>
                    <td><?= $wishlist->has('user') ? $this->Html->link($wishlist->user->id, ['controller' => 'Users', 'action' => 'view', $wishlist->user->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Product') ?></th>
                    <td><?= $wishlist->has('product') ? $this->Html->link($wishlist->product->name, ['controller' => 'Products', 'action' => 'view', $wishlist->product->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($wishlist->Id) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
