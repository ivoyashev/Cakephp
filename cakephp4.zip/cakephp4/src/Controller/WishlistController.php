<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Wishlist Controller
 *
 * @property \App\Model\Table\WishlistTable $Wishlist
 * @method \App\Model\Entity\Wishlist[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class WishlistController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Users', 'Products'],
        ];
        $wishlist = $this->paginate($this->Wishlist);

        $this->set(compact('wishlist'));
    }

    /**
     * View method
     *
     * @param string|null $id Wishlist id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $wishlist = $this->Wishlist->get($id, [
            'contain' => ['Users', 'Products'],
        ]);

        $this->set(compact('wishlist'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add($productId) {
        $userId = $this->Auth->user('id');

        $wishlist = $this->Wishlist->find('first', array(
            'conditions' => array(
                'Wishlist.user_id' => $userId,
                'Wishlist.product_id' => $productId
            )
        ));

        if ($wishlist) {
            // Item already in wishlist
            $this->Session->setFlash('This item is already in your wishlist.');
            $this->redirect($this->referer());
        } else {
            // Add item to wishlist
            $data = array(
                'Wishlist' => array(
                    'user_id' => $userId,
                    'product_id' => $productId
                )
            );

            if ($this->Wishlist->save($data)) {
                $this->Session->setFlash('Item added to your wishlist.');
                $this->redirect($this->referer());
            } else {
                $this->Session->setFlash('There was an error adding the item to your wishlist.');
                $this->redirect($this->referer());
            }
        }
    }

    /**
     * Edit method
     *
     * @param string|null $id Wishlist id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $wishlist = $this->Wishlist->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $wishlist = $this->Wishlist->patchEntity($wishlist, $this->request->getData());
            if ($this->Wishlist->save($wishlist)) {
                $this->Flash->success(__('The wishlist has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The wishlist could not be saved. Please, try again.'));
        }
        $users = $this->Wishlist->Users->find('list', ['limit' => 200])->all();
        $products = $this->Wishlist->Products->find('list', ['limit' => 200])->all();
        $this->set(compact('wishlist', 'users', 'products'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Wishlist id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $wishlist = $this->Wishlist->get($id);
        if ($this->Wishlist->delete($wishlist)) {
            $this->Flash->success(__('The wishlist has been deleted.'));
        } else {
            $this->Flash->error(__('The wishlist could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
